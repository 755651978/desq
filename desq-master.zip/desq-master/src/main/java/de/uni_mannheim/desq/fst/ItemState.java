package de.uni_mannheim.desq.fst;

public final class ItemState {
	public int itemFid; // =0 for eps
	public State state;
}
